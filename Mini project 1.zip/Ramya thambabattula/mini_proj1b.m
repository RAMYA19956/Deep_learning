%% 
[X,T] = bodyfat_dataset;
% % B.1
x_train = X(:,1:176);
x_valid = X(:,177:214);
x_test = X(:,215:252);
y_train = T(:,1:176);
y_valid = T(:,177:214);
y_test = T(:,215:252);

mse_train = {};
mse_val = {};
mse_test = {};

for i=1:10
    network = fitnet(15);
    network = train(network,x_train,y_train);
    y_tr_predict = network(x_train);
    y_val_predict = network(x_valid);
    y_te_predict = network(x_test);
    
    mse_tr = immse(y_train, y_tr_predict);
    mse_train = [mse_train, mse_tr];
    mse_v = immse(y_valid, y_val_predict);
    mse_val = [mse_val, mse_v];
    mse_te = immse(y_test, y_te_predict);
    mse_test = [mse_test, mse_te];
    
    network = init(network);
end
save net;

% Calculate mean and variance of MSEs
meanTrMSE = mean(cell2mat(mse_train));
varTrMSE = var(cell2mat(mse_train));
meanValMSE = mean(cell2mat(mse_val));
varValMSE = var(cell2mat(mse_val));
meanTeMSE = mean(cell2mat(mse_test));
varTeMSE = var(cell2mat(mse_test));

%% 


%b2 

x_train = X(:,1:76);
x_valid = X(:,77:124);
x_test = X(:,125:252);
y_train = T(:,1:76);
y_valid = T(:,77:124);
y_test = T(:,125:252);

mse_train = {};
mse_val = {};
mse_test = {};

for i=1:10
    network = fitnet(2);
    network = train(network,x_train,y_train);
    y_tr_predict = network(x_train);
    y_val_predict = network(x_valid);
    y_te_predict = network(x_test);
    
    mse_tr = immse(y_train, y_tr_predict);
    mse_train = [mse_train, mse_tr];
    mse_v = immse(y_valid, y_val_predict);
    mse_val = [mse_val, mse_v];
    mse_te = immse(y_test, y_te_predict);
    mse_test = [mse_test, mse_te];
    
    network = init(network);
end
save net;

% Calculate mean and variance of MSEs
meanTrMSE = mean(cell2mat(mse_train));
varTrMSE = var(cell2mat(mse_train));
meanValMSE = mean(cell2mat(mse_val));
varValMSE = var(cell2mat(mse_val));
meanTeMSE = mean(cell2mat(mse_test));
varTeMSE = var(cell2mat(mse_test));

%% 

x_train = X(:,1:76);
x_valid = X(:,77:124);
x_test = X(:,125:252);
y_train = T(:,1:76);
y_valid = T(:,77:124);
y_test = T(:,125:252);

mse_train = {};
mse_val = {};
mse_test = {};

for i=1:10
    network = fitnet(80);
    network = train(network,x_train,y_train);
    y_tr_predict = network(x_train);
    y_val_predict = network(x_valid);
    y_te_predict = network(x_test);
    
    mse_tr = immse(y_train, y_tr_predict);
    mse_train = [mse_train, mse_tr];
    mse_v = immse(y_valid, y_val_predict);
    mse_val = [mse_val, mse_v];
    mse_te = immse(y_test, y_te_predict);
    mse_test = [mse_test, mse_te];
    
    network = init(network);
end
save net;

% Calculate mean and variance of MSEs
meanTrMSE = mean(cell2mat(mse_train));
varTrMSE = var(cell2mat(mse_train));
meanValMSE = mean(cell2mat(mse_val));
varValMSE = var(cell2mat(mse_val));
meanTeMSE = mean(cell2mat(mse_test));
varTeMSE = var(cell2mat(mse_test));

%% 

x_train = X(:,1:76);
x_valid = X(:,77:252);
y_train = T(:,1:76);
y_valid = T(:,77:252);

mse_tr_w1 = {};
mse_val_w1 = {};
mse_tr_w2 = {};
mse_val_w2 = {};
%mse_test = {};

for i=1:10
    network_w1 = fitnet(80);
    network_w2 = fitnet(80);

    network_w1.trainParam.weightDecay = 0.1;
    network_w2.trainParam.weightDecay = 0.5;

    network_w1 = train(network_w1,x_train,y_train);
    network_w2 = train(network_w2, x_train, y_train);
    y_train_pred_w1 = network_w1(x_train);
    y_val_pred_w1 = network_w1(x_valid);
    y_train_pred_w2 = network_w2(x_train);
    y_val_pred_w2 = network_w2(x_valid);
    %y_te_pred = net(x_te);
    
    mse_train_w1 = immse(y_train, y_train_pred_w1);
    mse_tr_w1 = [mse_tr_w1, mse_train_w1];
    mse_v_w1 = immse(y_valid, y_val_pred_w1);
    mse_val_w1 = [mse_val_w1, mse_v_w1];

    mse_train_w2 = immse(y_train, y_train_pred_w2);
    mse_tr_w2 = [mse_tr_w2, mse_train_w2];
    mse_v_w2 = immse(y_valid, y_val_pred_w2);
    mse_val_w2 = [mse_val_w2, mse_v_w2];
   % mse_te = immse(y_te, y_te_pred);
    %mse_test = [mse_test, mse_te];
    
    network_w1 = init(network_w1);
    network_w2 = init(network_w2);
end
save net;

% Calculate mean and variance of MSEs
meanTrainMSE1 = mean(cell2mat(mse_tr_w1));
varianceTrainMSE1 = var(cell2mat(mse_tr_w1));
meanValMSE1 = mean(cell2mat(mse_val_w1));
varianceValMSE1 = var(cell2mat(mse_val_w1));
%meanTestMSE1 = mean(cell2mat(mse_test_w1));
%varianceTestMSE1 = var(cell2mat(mse_test_w1));


meanTrainMSE2 = mean(cell2mat(mse_tr_w2));
varianceTrainMSE2 = var(cell2mat(mse_tr_w2));
meanValMSE2 = mean(cell2mat(mse_val_w2));
varianceValMSE2 = var(cell2mat(mse_val_w2));
%meanTestMSE2 = mean(cell2mat(mse_test_w2));
%varianceTestMSE2 = var(cell2mat(mse_test_w2));%% 
%%
% % B1
x_train = X(:,1:176);
x_valid = X(:,177:214);
x_test = X(:,215:252);
y_train = T(:,1:176);
y_valid = T(:,177:214);
y_test = T(:,215:252);

mse_train = {};
mse_val = {};
mse_test = {};

for i=1:10
    network = fitnet(15);
    network = train(network,x_train,y_train);
    y_tr_predict = network(x_train);
    y_val_predict = network(x_valid);
    y_te_predict = network(x_test);
    
    mse_tr = immse(y_train, y_tr_predict);
    mse_train = [mse_train, mse_tr];
    mse_v = immse(y_valid, y_val_predict);
    mse_val = [mse_val, mse_v];
    mse_te = immse(y_test, y_te_predict);
    mse_test = [mse_test, mse_te];
    
    network = init(network);
end
save net;

% Calculate mean and variance of MSEs
meanTrMSE = mean(cell2mat(mse_train));
varTrMSE = var(cell2mat(mse_train));
meanValMSE = mean(cell2mat(mse_val));
varValMSE = var(cell2mat(mse_val));
meanTeMSE = mean(cell2mat(mse_test));
varTeMSE = var(cell2mat(mse_test));

%% 


%b2 

x_train = X(:,1:76);
x_valid = X(:,77:124);
x_test = X(:,125:252);
y_train = T(:,1:76);
y_valid = T(:,77:124);
y_test = T(:,125:252);

mse_train = {};
mse_val = {};
mse_test = {};

for i=1:10
    network = fitnet(2);
    network = train(network,x_train,y_train);
    y_tr_predict = network(x_train);
    y_val_predict = network(x_valid);
    y_te_predict = network(x_test);
    
    mse_tr = immse(y_train, y_tr_predict);
    mse_train = [mse_train, mse_tr];
    mse_v = immse(y_valid, y_val_predict);
    mse_val = [mse_val, mse_v];
    mse_te = immse(y_test, y_te_predict);
    mse_test = [mse_test, mse_te];
    
    network = init(network);
end
save net;

% Calculate mean and variance of MSEs
meanTrMSE = mean(cell2mat(mse_train));
varTrMSE = var(cell2mat(mse_train));
meanValMSE = mean(cell2mat(mse_val));
varValMSE = var(cell2mat(mse_val));
meanTeMSE = mean(cell2mat(mse_test));
varTeMSE = var(cell2mat(mse_test));

%% 

x_train = X(:,1:76);
x_valid = X(:,77:124);
x_test = X(:,125:252);
y_train = T(:,1:76);
y_valid = T(:,77:124);
y_test = T(:,125:252);

mse_train = {};
mse_val = {};
mse_test = {};

for i=1:10
    network = fitnet(80);
    network = train(network,x_train,y_train);
    y_tr_predict = network(x_train);
    y_val_predict = network(x_valid);
    y_te_predict = network(x_test);
    
    mse_tr = immse(y_train, y_tr_predict);
    mse_train = [mse_train, mse_tr];
    mse_v = immse(y_valid, y_val_predict);
    mse_val = [mse_val, mse_v];
    mse_te = immse(y_test, y_te_predict);
    mse_test = [mse_test, mse_te];
    
    network = init(network);
end
save net;

% Calculate mean and variance of MSEs
meanTrMSE = mean(cell2mat(mse_train));
varTrMSE = var(cell2mat(mse_train));
meanValMSE = mean(cell2mat(mse_val));
varValMSE = var(cell2mat(mse_val));
meanTeMSE = mean(cell2mat(mse_test));
varTeMSE = var(cell2mat(mse_test));

%% 

x_train = X(:,1:76);
x_valid = X(:,77:252);
y_train = T(:,1:76);
y_valid = T(:,77:252);

mse_tr_w1 = {};
mse_val_w1 = {};
mse_tr_w2 = {};
mse_val_w2 = {};
%mse_test = {};

for i=1:10
    network_w1 = fitnet(80);
    network_w2 = fitnet(80);

    network_w1.trainParam.weightDecay = 0.1;
    network_w2.trainParam.weightDecay = 0.5;

    network_w1 = train(network_w1,x_train,y_train);
    network_w2 = train(network_w2, x_train, y_train);
    y_train_pred_w1 = network_w1(x_train);
    y_val_pred_w1 = network_w1(x_valid);
    y_train_pred_w2 = network_w2(x_train);
    y_val_pred_w2 = network_w2(x_valid);
    %y_te_pred = net(x_te);
    
    mse_train_w1 = immse(y_train, y_train_pred_w1);
    mse_tr_w1 = [mse_tr_w1, mse_train_w1];
    mse_v_w1 = immse(y_valid, y_val_pred_w1);
    mse_val_w1 = [mse_val_w1, mse_v_w1];

    mse_train_w2 = immse(y_train, y_train_pred_w2);
    mse_tr_w2 = [mse_tr_w2, mse_train_w2];
    mse_v_w2 = immse(y_valid, y_val_pred_w2);
    mse_val_w2 = [mse_val_w2, mse_v_w2];
   % mse_te = immse(y_te, y_te_pred);
    %mse_test = [mse_test, mse_te];
    
    network_w1 = init(network_w1);
    network_w2 = init(network_w2);
end
save net;

% Calculate mean and variance of MSEs
meanTrainMSE1 = mean(cell2mat(mse_tr_w1));
varianceTrainMSE1 = var(cell2mat(mse_tr_w1));
meanValMSE1 = mean(cell2mat(mse_val_w1));
varianceValMSE1 = var(cell2mat(mse_val_w1));
%meanTestMSE1 = mean(cell2mat(mse_test_w1));
%varianceTestMSE1 = var(cell2mat(mse_test_w1));


meanTrainMSE2 = mean(cell2mat(mse_tr_w2));
varianceTrainMSE2 = var(cell2mat(mse_tr_w2));
meanValMSE2 = mean(cell2mat(mse_val_w2));
varianceValMSE2 = var(cell2mat(mse_val_w2));
%meanTestMSE2 = mean(cell2mat(mse_test_w2));
%varianceTestMSE2 = var(cell2mat(mse_test_w2));