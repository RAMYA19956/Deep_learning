[X,T] = bodyfat_dataset;
coe_corr = {};

for loops=1:13
    crr = corrcoef(X(loops,:),T);
    coe_corr = [coe_corr, crr(2,1)];
end

X_tr = X([2,4,5,6,7,8],1:189);
X_te = X([2,4,5,6,7,8],190:252);
Y_tr = T(:,1:189);
Y_te = T(:,190:252);

model_weight = X_tr'\Y_tr';

y_tr_pred = X_tr'*model_weight;
y_te_pred = X_te'*model_weight;

tr_mse = immse(Y_tr',y_tr_pred);
te_mse = immse(Y_te',y_te_pred);